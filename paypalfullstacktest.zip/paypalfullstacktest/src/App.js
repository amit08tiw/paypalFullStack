
import './App.css';
import Carousel from './components/carousel.js'

function App() {
  return (
    // <div className="App">
    //   <header className="App-header">
        
    //   </header>
    //   <Carousel />
    // </div>
    
    <div id="root"></div>
  );
}

export default App;
